import cv2

img = cv2.imread("./download.jpg")
# img_converted = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
# img_converted = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
# img_converted = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
img_converted = cv2.cvtColor(img, cv2.COLOR_HSV2RGB)
print(img_converted)
cv2.imshow("image", img_converted)
# cv2.imwrite("./download_converted.jpg", img_converted)
cv2.waitKey(0)
cv2.destroyAllWindows()
